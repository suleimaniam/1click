<?php

namespace AmeliaBooking\Application\Commands\User\Provider;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetProvidersCommand
 *
 * @package AmeliaBooking\Application\Commands\User\Provider
 */
class GetProvidersCommand extends Command
{

}
