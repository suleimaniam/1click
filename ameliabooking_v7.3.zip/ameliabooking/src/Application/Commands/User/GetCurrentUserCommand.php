<?php

namespace AmeliaBooking\Application\Commands\User;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCurrentUserCommand
 *
 * @package AmeliaBooking\Application\Commands\User
 */
class GetCurrentUserCommand extends Command
{

}
