<?php

namespace AmeliaBooking\Application\Commands\Location;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeleteLocationCommand
 *
 * @package AmeliaBooking\Application\Commands\Location
 */
class DeleteLocationCommand extends Command
{

}
