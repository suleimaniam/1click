<?php

namespace AmeliaBooking\Application\Commands\Location;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetLocationDeleteEffectCommand
 *
 * @package AmeliaBooking\Application\Commands\Location
 */
class GetLocationDeleteEffectCommand extends Command
{

}
