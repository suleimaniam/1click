<?php

namespace AmeliaBooking\Application\Commands\Location;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetLocationCommand
 *
 * @package AmeliaBooking\Application\Commands\Location
 */
class GetLocationCommand extends Command
{

}
