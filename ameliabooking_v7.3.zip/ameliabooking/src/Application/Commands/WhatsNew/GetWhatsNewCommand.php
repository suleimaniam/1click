<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\WhatsNew;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetWhatsNewCommand
 *
 * @package AmeliaBooking\Application\Commands\WhatsNew
 */
class GetWhatsNewCommand extends Command
{

}
