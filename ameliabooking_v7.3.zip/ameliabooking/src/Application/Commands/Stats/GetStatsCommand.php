<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Stats;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetStatsCommand
 *
 * @package AmeliaBooking\Application\Commands\Stats
 */
class GetStatsCommand extends Command
{

}
