<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class WhatsAppWebhookCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class WhatsAppWebhookRegisterCommand extends Command
{

}
