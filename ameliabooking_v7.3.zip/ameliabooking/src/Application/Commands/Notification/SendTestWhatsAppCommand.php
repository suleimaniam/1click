<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class SendTestWhatsAppCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class SendTestWhatsAppCommand extends Command
{

}
