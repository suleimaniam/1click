<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateNotificationCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class UpdateNotificationCommand extends Command
{

}
