<?php

namespace AmeliaBooking\Application\Commands\Entities;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetEntitiesCommand
 *
 * @package AmeliaBooking\Application\Commands\Entities
 */
class GetEntitiesCommand extends Command
{

}
