<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class RejectBookingRemotelyCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class RejectBookingRemotelyCommand extends Command
{

}
