<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class ApproveBookingRemotelyCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class ApproveBookingRemotelyCommand extends Command
{

}
