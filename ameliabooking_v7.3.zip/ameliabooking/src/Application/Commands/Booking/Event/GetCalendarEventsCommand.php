<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCalendarEventsCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class GetCalendarEventsCommand extends Command
{

}
