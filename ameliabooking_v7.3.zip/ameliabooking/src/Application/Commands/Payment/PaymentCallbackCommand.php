<?php

namespace AmeliaBooking\Application\Commands\Payment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class PaymentCallbackCommand
 *
 * @package AmeliaBooking\Application\Commands\Payment
 */
class PaymentCallbackCommand extends Command
{

}
