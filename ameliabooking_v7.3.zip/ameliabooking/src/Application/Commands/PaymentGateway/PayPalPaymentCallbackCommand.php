<?php

namespace AmeliaBooking\Application\Commands\PaymentGateway;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class PayPalPaymentCallbackCommand
 *
 * @package AmeliaBooking\Application\Commands\PaymentGateway
 */
class PayPalPaymentCallbackCommand extends Command
{

}
