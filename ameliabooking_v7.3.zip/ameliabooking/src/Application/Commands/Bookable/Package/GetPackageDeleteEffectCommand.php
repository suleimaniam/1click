<?php

namespace AmeliaBooking\Application\Commands\Bookable\Package;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetPackageDeleteEffectCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Package
 */
class GetPackageDeleteEffectCommand extends Command
{

}
