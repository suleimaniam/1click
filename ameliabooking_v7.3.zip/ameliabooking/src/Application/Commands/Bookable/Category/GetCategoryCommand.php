<?php

namespace AmeliaBooking\Application\Commands\Bookable\Category;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCategoryCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Category
 */
class GetCategoryCommand extends Command
{

}
