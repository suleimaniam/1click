<?php

namespace AmeliaBooking\Application\Commands\Bookable\Category;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddCategoryCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Category
 */
class AddCategoryCommand extends Command
{

}
