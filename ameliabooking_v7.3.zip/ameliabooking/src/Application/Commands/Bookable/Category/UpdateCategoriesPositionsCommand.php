<?php

namespace AmeliaBooking\Application\Commands\Bookable\Category;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateCategoriesPositionsCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Category
 */
class UpdateCategoriesPositionsCommand extends Command
{

}
